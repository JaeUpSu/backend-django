from django.shortcuts import render
from django.http import HttpResponse
from .models import User

# Create your views here.
def show_user(request):
    user_list = User.objects.order_by('date_joined')
    context = {"user_list":user_list}
    return render(request, 'users/user_list.html', context)